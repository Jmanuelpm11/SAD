kinit jpeinado
exit
